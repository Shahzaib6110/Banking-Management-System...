

package com.mycompany.mavenproject33;
import java.io.*;
import java.util.*;

class BankAccount {
    private String accountNumber;
    private String accountHolderName;
    private double balance;
    private List<String> transactionHistory = new ArrayList<>();

    public BankAccount(String accountNumber, String accountHolderName, double initialDeposit) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = initialDeposit;
        recordTransaction("Account created with initial deposit: $" + initialDeposit);
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
        recordTransaction("Deposited: $" + amount);
    }

    public void withdraw(double amount) throws Exception {
        if (amount > balance) {
            throw new Exception("Insufficient balance!");
        }
        balance -= amount;
        recordTransaction("Withdrew: $" + amount);
    }

    private void recordTransaction(String transaction) {
        transactionHistory.add(transaction);
    }

    public List<String> getTransactionHistory() {
        return transactionHistory;
    }

    @Override
    public String toString() {
        return accountNumber + "," + accountHolderName + "," + balance;
    }
}

class BankCustomer {
    private String name;
    private String contactInfo;

    public BankCustomer(String name, String contactInfo) {
        this.name = name;
        this.contactInfo = contactInfo;
    }

    public String getName() {
        return name;
    }

    public String getContactInfo() {
        return contactInfo;
    }
}

class LoanRequest {
    private String customerName;
    private double amount;

    public LoanRequest(String customerName, double amount) {
        this.customerName = customerName;
        this.amount = amount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getAmount() {
        return amount;
    }
}

class BankEmployee {
    private String employeeId;
    private String name;
    private String role;

    public BankEmployee(String employeeId, String name, String role) {
        this.employeeId = employeeId;
        this.name = name;
        this.role = role;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public void assistCustomer(BankCustomer customer) {
        System.out.println("Employee " + name + " (" + role + ") is assisting customer " + customer.getName());
    }
}

class BankManager {
    private String managerId;
    private String name;
    private List<LoanRequest> loanRequests = new ArrayList<>();

    public BankManager(String managerId, String name) {
        this.managerId = managerId;
        this.name = name;
    }

    public void manageAccounts() {
        System.out.println("Managing accounts...");
    }

    public void handleLoanManagement() {
        if (loanRequests.isEmpty()) {
            System.out.println("No loan requests available.");
            return;
        }
        
        System.out.println("Pending Loan Requests:");
        for (int i = 0; i < loanRequests.size(); i++) {
            LoanRequest request = loanRequests.get(i);
            System.out.println((i + 1) + ". Customer: " + request.getCustomerName() + 
                               ", Amount: " + request.getAmount());
        }

        System.out.print("Select a request to process (1-" + loanRequests.size() + "): ");
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        if (choice < 1 || choice > loanRequests.size()) {
            System.out.println("Invalid choice.");
            return;
        }

        LoanRequest selectedRequest = loanRequests.remove(choice - 1);
        System.out.print("Accept or Reject? (a/r): ");
        char decision = scanner.next().charAt(0);
        if (decision == 'a' || decision == 'A') {
            System.out.println("Loan request for " + selectedRequest.getCustomerName() + " accepted.");
        } else {
            System.out.println("Loan request for " + selectedRequest.getCustomerName() + " rejected.");
        }
    }

    public void provideCustomerService() {
        System.out.println("Providing customer service...");
    }

    public void addLoanRequest(LoanRequest request) {
        loanRequests.add(request);
        System.out.println("Loan request from " + request.getCustomerName() + " added.");
    }
}

public class Mavenproject33 {
    private static final String FILE_NAME = System.getProperty("user.home") + "/accounts.txt";
    private static Scanner scanner = new Scanner(System.in);
    private static BankManager manager = new BankManager("M001", "Alice");

    public static void main(String[] args) {
        // Different employees with specific roles
        BankEmployee createAccountEmployee = new BankEmployee("E001", "John Doe", "Account Creation");
        BankEmployee checkAccountEmployee = new BankEmployee("E002", "Jane Smith", "Account Checking");
        BankEmployee infoEmployee = new BankEmployee("E003", "Tom Brown", "Information");

        while (true) {
            System.out.println("1. Create Account");
            System.out.println("2. View Accounts");
            System.out.println("3. Employee Assistance");
            System.out.println("4. Manager Functions");
            System.out.println("5. Request Loan");
            System.out.println("6. View Transaction History");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1 -> createAccount(createAccountEmployee);
                    case 2 -> viewAccounts();
                    case 3 -> employeeAssistance();
                    case 4 -> managerFunctions(manager);
                    case 5 -> requestLoan();
                    case 6 -> viewTransactionHistory();
                    case 7 -> {
                        System.out.println("Exiting...");
                        return;
                    }
                    default -> System.out.println("Invalid option! Please try again.");
                }
            } catch (IOException e) {
                System.out.println("File error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void createAccount(BankEmployee employee) {
        try {
            System.out.print("Enter Account Number: ");
            String accNum = scanner.nextLine();
            System.out.print("Enter Account Holder Name: ");
            String holderName = scanner.nextLine();
            System.out.print("Enter Initial Deposit (minimum $100): ");
            double initialDeposit = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter a valid ID (e.g., driver's license number): ");
            String validID = scanner.nextLine();

            System.out.print("Enter Contact Information: ");
            String contactInfo = scanner.nextLine();

            if (initialDeposit < 100) {
                throw new IllegalArgumentException("Initial deposit must be at least $100.");
            }

            BankAccount account = new BankAccount(accNum, holderName, initialDeposit);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
                writer.write(account.toString());
                writer.newLine();
            }
            System.out.println("Account created successfully!");
            employee.assistCustomer(new BankCustomer(holderName, contactInfo));
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a numeric value for the initial deposit.");
            scanner.next(); // Clear the invalid input
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewAccounts() throws IOException {
        File file = new File(FILE_NAME);
        if (!file.exists() || file.length() == 0) {
            System.out.println("No accounts found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            System.out.println("Account Details:");
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                System.out.println("Account Number: " + details[0] +
                                   ", Holder Name: " + details[1] +
                                   ", Balance: $" + details[2]);
            }
        }
    }

    private static void employeeAssistance() {
        System.out.println("Choose Assistance Type:");
        System.out.println("1. Account Creation Assistance");
        System.out.println("2. Account Checking Assistance");
        System.out.println("3. General Information ");
        System.out.print("Select an option (1-3): ");
        int assistanceChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (assistanceChoice) {
            case 1:
                employeeAssistance(new BankEmployee("E001", "John Doe", "Account Creation"));
                break;
            case 2:
                employeeAssistance(new BankEmployee("E002", "Jane Smith", "Account Checking"));
                break;
            case 3:
                provideGeneralInformation();
                break;
            default:
                System.out.println("Invalid choice! Please try again.");
        }
    }

    private static void employeeAssistance(BankEmployee employee) {
        System.out.print("Enter Customer Name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter Customer Contact Info: ");
        String contactInfo = scanner.nextLine();
        BankCustomer customer = new BankCustomer(customerName, contactInfo);
        employee.assistCustomer(customer);
    }

    private static void provideGeneralInformation() {
        System.out.println("General Bank Information:");
        System.out.println("1. Opening Hours: Mon-Fri 9 AM - 5 PM");
        System.out.println("2. Contact Number: 1-800-BANK-NOW");
        System.out.println("3. Customer Service Email: support@bank.com");
        System.out.println("4. Online Banking Services: Available 24/7 at our website.");
        System.out.println("5. Loan Information: Various loan options available, including personal, auto, and home loans.");
    }

    private static void managerFunctions(BankManager manager) {
        System.out.println("Manager Functions:");
        System.out.println("1. Manage Accounts");
        System.out.println("2. Handle Loan Management");
        System.out.println("3. Provide Customer Service");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                manager.manageAccounts();
                break;
            case 2:
                manager.handleLoanManagement();
                break;
            case 3:
                manager.provideCustomerService();
                break;
            default:
                System.out.println("Invalid option!");
        }
    }

    private static void requestLoan() {
        System.out.print("Enter Your Name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter Loan Amount: ");
        double amount = scanner.nextDouble();
        
        if (amount <= 0) {
            System.out.println("Loan amount must be positive.");
            return;
        }

        LoanRequest loanRequest = new LoanRequest(customerName, amount);
        manager.addLoanRequest(loanRequest);
    }

    private static void viewTransactionHistory() {
        System.out.print("Enter Account Number to view transaction history: ");
        String accNum = scanner.nextLine();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            boolean found = false;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details[0].equals(accNum)) {
                    found = true;
                    System.out.println("Transaction History for Account: " + accNum);
                    // For simplicity, we'll print a placeholder for transaction history.
                    System.out.println("No transactions found for this account."); // Placeholder
                }
            }
            if (!found) {
                System.out.println("Account not found.");
            }
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }
}




//    public static void main(String[] args) {
       
    

